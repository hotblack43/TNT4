#!/usr/bin/python

from ABE_ADCPi import ADCPi
from ABE_helpers import ABEHelpers
import time
import os
import smbus
import struct
import math
import numpy
from time import gmtime, strftime
import datetime
from astropy.time import Time
from subprocess import call


"""
================================================
ABElectronics ADC Pi 8-Channel ADC demo
Version 1.0 Created 09/05/2014
Version 1.1 16/11/2014 updated code and functions to PEP8 format

Requires python smbus to be installed
run with: python demo-read_voltage.py
================================================


Initialise the ADC device using the default addresses and sample rate,
change this value if you have changed the address selection jumpers

Sample rate can be 12,14, 16 or 18
"""


i2c_helper = ABEHelpers()
bus = i2c_helper.get_smbus()
adc = ADCPi(bus, 0x68, 0x69, 18)
# set the gain 1,2,4 or 8
adc.set_pga(8)

while (True):

# Read the time
            t = Time(datetime.datetime.now() , scale='utc')
            utc2=float(("%.19f" % t.jd))

    # read from adc channels and print to screen
            voltage1=adc.read_voltage(1)
            voltage4=adc.read_voltage(4)

# Read the time again and average
            t = Time(datetime.datetime.now() , scale='utc')
            utc=float(("%.19f" % t.jd))
            utc= (utc2+utc)/2.0              # average of before/after timers

# Open output files
            with open('/home/pi/ABElectronics_Python_Libraries/ADCPi/outfile.dat', 'a+') as outfile:

# then print to file
                outfile.write('% 01.15f % 01.8f % 01.8f \n' % (utc,voltage1,voltage4))

# and close it
                outfile.close()

# sleep a bit
            time.sleep(30.)
 
# shorten the file so it does not grow too big
            os.system('tail -n 86400 /home/pi/ABElectronics_Python_Libraries/ADCPi/outfile.dat > /home/pi/ABElectronics_Python_Libraries/ADCPi/erase.me.now')
            os.system('cp /home/pi/ABElectronics_Python_Libraries/ADCPi/erase.me.now /home/pi/ABElectronics_Python_Libraries/ADCPi/outfile.dat')

