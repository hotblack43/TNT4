#!/usr/bin/env python
# coding: latin-1



import datetime
from astropy.time import Time
t = Time(datetime.datetime.now() , scale='utc')
utc=float(("%.19f" % t.jd))
print "%.19f" % utc
